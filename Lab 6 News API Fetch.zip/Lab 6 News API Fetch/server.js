const express = require('express');
const fetch = require('node-fetch');
const dotenv = require('dotenv');

// Load environment variables from .env file
dotenv.config();

const app = express();
const port = process.env.PORT || 3000;
const apiKey = process.env.API_KEY;

// Set up CORS (Cross-Origin Resource Sharing) to allow requests from your frontend
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    next();
});

// News API endpoint that returns 10 random articles
app.get('/news', async (req, res) => {
    try {
        const response = await fetch(`https://newsapi.org/v2/top-headlines?country=us&apiKey=${apiKey}`);
        const data = await response.json();
        
        // Return only 10 random news articles
        const randomArticles = data.articles
            .sort(() => 0.5 - Math.random()) // Shuffle the array
            .slice(0, 10); // Pick 10 random articles
        
        res.json(randomArticles);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching news' });
    }
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});